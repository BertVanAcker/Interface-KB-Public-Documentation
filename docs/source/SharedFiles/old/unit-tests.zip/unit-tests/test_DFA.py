import unittest
import time
from Interface_KB import KB_Interface,InterfaceObjects
from Interface_KB.InterfaceObjects import *

class test_DFA(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        self.JSON = True
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds


    def test_getDFARules(self):
        DFARules_Selector = []
        DFARules_Evaluator = []
        if self.model != None:
            DFARules_Selector = self.KB_Interface.getASG_DFARules('ASG-1', "Selector")
            DFARules_Evaluator = self.KB_Interface.getASG_DFARules('ASG-1', "Evaluator")
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')  # TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_getDFARules.pacopackage')  # TODO: adapt to one version!!
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            DFARules_Selector = self.KB_Interface.getASG_DFARules('ASG-1', "Selector")
            DFARules_Evaluator = self.KB_Interface.getASG_DFARules('ASG-1', "Evaluator")

        print(DFARules_Selector)
        print(DFARules_Evaluator)

        # -----------------------CHECKS SELECTOR----------------------------------
        self.assertEqual(len(DFARules_Selector), 2)
        # first rule
        self.assertEqual(DFARules_Selector[0].RuleType, "DFA_MaxValue")
        self.assertEqual(DFARules_Selector[0].Name, "rule-height-max")
        self.assertEqual(DFARules_Selector[0].Description, "rule-height-max")
        self.assertEqual(DFARules_Selector[0].isAppliedToProduct, False)
        self.assertEqual(DFARules_Selector[0].isAppliedToProductPart, False)
        self.assertEqual(DFARules_Selector[0].isAppliedToAssemblySequence, False)
        # self.assertEqual(DFARules_Selector[0]., 0)                       #TODO: check how we can validate this
        # self.assertEqual(DFARules_Selector[0][7], 0)                       #TODO: check how we can validate this
        self.assertEqual(DFARules_Selector[0].optionList[0][0], 'TE')
        self.assertEqual(DFARules_Selector[0].optionList[0][1], [True])
        self.assertEqual(DFARules_Selector[0].optionList[1][0], 'Option1')
        self.assertEqual(DFARules_Selector[0].optionList[1][1], ['OptionEnumSelect'])
        # self.assertEqual(DFARules_Selector[0][9][0], Height=1)             #TODO: check how we can validate this
        self.assertEqual(DFARules_Selector[0].property[1], 100.0)
        # second rule
        self.assertEqual(DFARules_Selector[1].RuleType, "DFA_MinValue")
        self.assertEqual(DFARules_Selector[1].Name, "rule-min-footprint")
        self.assertEqual(DFARules_Selector[1].Description, "foot")
        self.assertEqual(DFARules_Selector[1].isAppliedToProduct, False)
        self.assertEqual(DFARules_Selector[1].isAppliedToProductPart, False)
        self.assertEqual(DFARules_Selector[1].isAppliedToAssemblySequence, False)
        # self.assertEqual(DFARules_Selector[1][6], 0)                       #TODO: check how we can validate this
        # self.assertEqual(DFARules_Selector[1][7], 0)                       #TODO: check how we can validate this
        self.assertEqual(DFARules_Selector[1].optionList, [])

        # self.assertEqual(DFARules_Selector[0][9][0], Footprint=2)             #TODO: check how we can validate this
        self.assertEqual(DFARules_Selector[1].property[1], 150.0)

        # -----------------------CHECKS EVALUATOR----------------------------------
        self.assertEqual(len(DFARules_Evaluator), 3)
        # first rule
        self.assertEqual(DFARules_Evaluator[0].RuleType, "DFA_BoundValue")
        self.assertEqual(DFARules_Evaluator[0].Name, "rule-parts-bound")
        self.assertEqual(DFARules_Evaluator[0].Description, "rule-parts-bound")
        self.assertEqual(DFARules_Evaluator[0].isAppliedToProduct, False)
        self.assertEqual(DFARules_Evaluator[0].isAppliedToProductPart, False)
        self.assertEqual(DFARules_Evaluator[0].isAppliedToAssemblySequence, False)
        # self.assertEqual(DFARules_Evaluator[0][6], 0)                       #TODO: check how we can validate this
        # self.assertEqual(DFARules_Evaluator[0][7], 0)                       #TODO: check how we can validate this
        self.assertEqual(DFARules_Evaluator[0].optionList, [])

        # self.assertEqual(DFARules_Selector[0][9][0], Footprint=2)             #TODO: check how we can validate this
        self.assertEqual(DFARules_Evaluator[0].property[1], 1.0)
        self.assertEqual(DFARules_Evaluator[0].property[2], 100.0)
        # 3d rule
        self.assertEqual(DFARules_Evaluator[2].RuleType, "DFA_Gravity")
        self.assertEqual(DFARules_Evaluator[2].Name, "gravity")
        self.assertEqual(DFARules_Evaluator[2].Description, "gravity")
        self.assertEqual(DFARules_Evaluator[2].isAppliedToProduct, False)
        self.assertEqual(DFARules_Evaluator[2].isAppliedToProductPart, False)
        self.assertEqual(DFARules_Evaluator[2].isAppliedToAssemblySequence, False)
        # self.assertEqual(DFARules_Evaluator[2][6], 0)                       #TODO: check how we can validate this
        # self.assertEqual(DFARules_Evaluator[2][7], 0)                       #TODO: check how we can validate this
        self.assertEqual(DFARules_Evaluator[2].optionList, [])

        # self.assertEqual(DFARules_Selector[2][9][0], Score=0)             #TODO: check how we can validate this

    def test_updateDFARules(self):
        if not self.JSON:
            #--manual setup DFA rules
            DFARule_Selector = ['DFA_MaxValue', 'rule-height-max', 'Hello World', True, False, False, 0, 0, [['TE', [True]]], ['Option1', ['OptionEnumSelect']], [1, 100.0]] #[[['DFA_MaxValue', 'rule-height-max', 'rule-height-max', False, False, False, 0, 0, [['TE', [True]]], ['Option1', ['OptionEnumSelect']]], [1, 100.0]], ['DFA_MinValue', 'rule-min-footprint', 'foot', False, False, False, 0, 0, [], [2, 150.0]]]
            DFARule_Evaluator = ['DFA_BoundValue', 'rule-parts-bound', 'Hello World 2', False, False, False, 0, 0, [], [4, 1.0, 100.0]]#[['DFA_BoundValue', 'rule-parts-bound', 'rule-parts-bound', False, False, False, 0, 0, [], [4, 1.0, 100.0]], [1, 'f', 'f', False, False, False, 0, 0, []], ['DFA_Gravity', 'gravity', 'gravity', False, False, False, 0, 0, []]]

            # ------------------------specify interface object START -----------------------------
            DFARule_Selector = DFARule(None,RuleType='DFA_MaxValue', Name='rule-height-max', Description='Hello World', isAppliedToProduct=True, isAppliedToProductPart=False, isAppliedToAssemblySequence=False, hasScorePropagation=0, hasScoreType=0,optionList=['TE', [True]])
            DFARule_Evaluator = DFARule(None,RuleType='DFA_BoundValue', Name='rule-parts-bound', Description='Hello World 2', isAppliedToProduct=False, isAppliedToProductPart=False, isAppliedToAssemblySequence=False, hasScorePropagation=0, hasScoreType=0,optionList=[])
            DFARule_Evaluator.property = [4, 1.0, 100.0]
            # ------------------------specify interface object END  -----------------------------
        else:
            # --JSON import of DFA rules
            jsonDescriptor = self.KB_Interface.resolvePath('input/JSON-docs/DFARule_Selector.json')
            DFARule_Selector = DFARule(JSONDescriptor=jsonDescriptor)
            jsonDescriptor = self.KB_Interface.resolvePath('input/JSON-docs/DFARule_Evaluator.json')
            DFARule_Evaluator = DFARule(JSONDescriptor=jsonDescriptor)

        if self.model != None:
            x=0
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')  # TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_updateDFARules.pacopackage')  # TODO: adapt to one version!!
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.updateASG_DFARules('ASG-1', "Selector",DFARule_Selector)
            self.KB_Interface.updateASG_DFARules('ASG-1', "Evaluator",DFARule_Evaluator)


        # -----------------------CHECKS SELECTOR----------------------------------
