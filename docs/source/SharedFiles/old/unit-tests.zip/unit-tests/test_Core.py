import unittest
import time
from Interface_KB import KB_Interface,InterfaceObjects

class test_Core(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds

    def test_CreateDynamicInstance(self):
        #mock-up
        path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
        path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'

        self.model = self.KB_Interface.importInstanceModel(path_ecore,path_KB)
        #-----------------------CHECKS----------------------------------
        self.assertNotEqual(self.model,None)

# ---------------------------------------------
#
#   Product test functions
#
# ---------------------------------------------
    def test_getProduct(self):
        if self.model != None:
            product = self.KB_Interface.getProduct()
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version5/PACoMM.ecore')  # TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/OldGearBox.xmi')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getProduct()

        # -----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "OldGearBox")
        self.assertEqual(InterfaceObject_received.STEPFile,
                         "C:/Users/alexander.decock/Local Documents/SVN/PACo/RuleTestsForUGM/data/FCStd/OldGearBox.FCStd")

    def test_updateProduct(self):

        # load the json file to perform update
        jsonPath = self.KB_Interface.resolvePath('input/JSON-docs/updateASGModel.json')
        interfaceObject = InterfaceObjects.ASG(jsonPath)
        interfaceObject = InterfaceObjects.Product(Name='OldGearBox', STEPFile='c:/NEW/PATH/TO/THE/STEPFILE')

        if self.model != None:
            product = self.KB_Interface.getProduct()
        else:
            path_ecore = self.KB_Interface.resolvePath(
                'input/metamodel/Version5/PACoMM.ecore')  # TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_updateProduct.xmi')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)

            # updating the ASG model
            error = self.KB_Interface.updateProduct(interfaceObject=interfaceObject)

            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getProduct()

        # -----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "OldGearBox")
        self.assertEqual(InterfaceObject_received.STEPFile, "c:/NEW/PATH/TO/THE/STEPFILE")

        # ---------------------------------node: Product attribute: all--------------------------------------------------------------------

    @unittest.skip("Function-under-test not yet implemented")
    def test_setProduct(self):

        # load the json file to perform update
        jsonPath = self.KB_Interface.resolvePath('input/JSON-docs/updateASGModel.json')
        interfaceObject = InterfaceObjects.ASG(jsonPath)
        interfaceObject = InterfaceObjects.Product(Name='OldGearBox', STEPFile='c:/NEW/PATH/TO/THE/STEPFILE')

        if self.model != None:
            product = self.KB_Interface.getProduct()
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version5/PACoMM.ecore')
            path_KB = self.KB_Interface.resolvePath(
                'input/KB_examples/test_setProduct.xmi')  # TODO: make version where no Product is defined!
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)

            # updating the ASG model
            error = self.KB_Interface.setProduct(interfaceObject=interfaceObject)

            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getProduct()

        # -----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "OldGearBox")
        self.assertEqual(InterfaceObject_received.STEPFile, "c:/NEW/PATH/TO/THE/STEPFILE")

# ---------------------------------------------
#
#   ProductPart test functions
#   #TODO:update the functions (set) -> allProductParts AND productPart('Name')
# ---------------------------------------------

    def test_getProductPart(self):
        if self.model != None:
            product = self.KB_Interface.getProduct()
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version5/PACoMM.ecore')  # TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/OldGearBox.xmi')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getProductPart('(3) Input Shaft')

        # -----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, '(3) Input Shaft')
        self.assertEqual(InterfaceObject_received.ProductType,"Unknown")
        self.assertEqual(InterfaceObject_received.material,  ['Structural Steel', 0.0, 0.0, 7850.0, 0.0, ''])
        self.assertEqual(len(InterfaceObject_received.parameterList), 2)
        #TODO:extend to check the parameters
        self.assertEqual(len(InterfaceObject_received.partList), 1)
        # TODO:extend to check the product parts

    def test_getAllProductParts(self):
        if self.model != None:
            product = self.KB_Interface.getProduct()
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version5/PACoMM.ecore')  # TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/OldGearBox.xmi')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObjectList = self.KB_Interface.getAllProductParts()

        # -----------------------CHECKS----------------------------------
        self.assertEqual(len(InterfaceObjectList), 11)
        # TODO:extend to check the product parts seperatly

    def test_updateProductPart(self):

        # load the json file to perform update
        jsonPath = self.KB_Interface.resolvePath('input/JSON-docs/updateProductPart.json')
        interfaceObject = InterfaceObjects.ProductPart(jsonPath)

        if self.model != None:
            product = self.KB_Interface.getProduct()
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version5/PACoMM.ecore')  # TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_updateProductPart.xmi')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)

            # perform update
            error = self.KB_Interface.updateProductPart(interfaceObject)

            # verify update by re-importing
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getProductPart('(3) Input Shaft')

        # -----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, '(3) Input Shaft')
        #self.assertEqual(InterfaceObject_received.Description, 'Description NEW')
        self.assertEqual(InterfaceObject_received.ProductType,"Unknown")
        self.assertEqual(InterfaceObject_received.material,  ['Structural Steel(SS)', 0.0, 0.0, 7850.0, 0.0, ''])
        self.assertEqual(len(InterfaceObject_received.parameterList), 2)
        self.assertEqual(InterfaceObject_received.parameterList[0].Value, "[1mm]")
        self.assertEqual(InterfaceObject_received.parameterList[1].Value, "[10Nm^-1]")
        #TODO:extend to check the parameters
        self.assertEqual(len(InterfaceObject_received.partList), 1)
        # TODO:extend to check the product parts

    def test_updateAllProductPart(self):

        interfaceObjectList = []

        # load the json file to perform update
        jsonPath = self.KB_Interface.resolvePath('input/JSON-docs/InputShaft.json')
        interfaceObject1 = InterfaceObjects.ProductPart(jsonPath)
        interfaceObjectList.append(interfaceObject1)

        # load the json file to perform update
        jsonPath = self.KB_Interface.resolvePath('input/JSON-docs/SmallGear.json')
        interfaceObject2 = InterfaceObjects.ProductPart(jsonPath)
        interfaceObjectList.append(interfaceObject2)

        if self.model != None:
            product = self.KB_Interface.getProduct()
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version5/PACoMM.ecore')  # TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_updateAllProductParts.xmi')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)

            # perform update
            error = self.KB_Interface.updateAllProductParts(interfaceObjectList)

            # verify update by re-importing
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            interfaceObjectList_received = self.KB_Interface.getAllProductParts()

        # -----------------------CHECKS----------------------------------
        for interfaceObject in interfaceObjectList_received:
            if interfaceObject.Name=='(3) Input Shaft':
                self.assertEqual(interfaceObject.Name, '(3) Input Shaft')
                #self.assertEqual(InterfaceObject_received.Description, 'Description NEW')
                self.assertEqual(interfaceObject.ProductType,"Unknown")
                self.assertEqual(interfaceObject.material,  ['Structural Steel(SS)', 0.0, 0.0, 7850.0, 0.0, ''])
                self.assertEqual(len(interfaceObject.parameterList), 2)
                self.assertEqual(interfaceObject.parameterList[0].Value, "[10mm]")
                self.assertEqual(interfaceObject.parameterList[1].Value, "[50Nm^-1]")
                #TODO:extend to check the parameters
                self.assertEqual(len(interfaceObject.partList), 1)
                # TODO:extend to check the product parts
        for interfaceObject in interfaceObjectList_received:
            if interfaceObject.Name=='(8) Small Gear':
                self.assertEqual(interfaceObject.Name, '(8) Small Gear')
                self.assertEqual(interfaceObject.ProductType, "GEAR")
                self.assertEqual(interfaceObject.material, ['Structural Steel(SS)', 0.0, 0.0, 7850.0, 0.0, ''])


# ---------------------------------------------
#
#   Product Analysis test functions
#   #TODO:update the functions (get,update,set)
# ---------------------------------------------
    @unittest.skip("Function-under-test not yet implemented")
    def test_setProductAnalysis(self):
        boundaryconditions = []
        loads = [['impuls', 10000.0]]
        contacts = []
        AnalysisList = [['analysisName',"analysisType",'modelFile',100,['Mesh3D',"Mesh1d"],boundaryconditions,loads,contacts]]
        if self.model != None:
            self.KB_Interface.setProductAnalysis(AnalysisList)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setProductAnalysis(AnalysisList)




        self.assertEqual(True, False)


# ---------------------------------------------
#
#   AssemblySequence test functions
#   #TODO:update the functions (get,update,set) -> allSequences AND Sequence('Name')
# ---------------------------------------------

    def test_getAssemblySequence(self):
        AssenblySeqeunces = None
        if self.model != None:
            AssenblySeqeunces = self.KB_Interface.getAssemblySequences()
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')  # TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_getAssemblySequence.pacopackage')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getAssemblySequence("AS-1")
        # -----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "SUB-1")
        self.assertEqual(InterfaceObject_received.AssemblyMetric[0], "OP-1")
        self.assertEqual(InterfaceObject_received.AssemblyMetric[1], "0.89")    #TODO: this needs to be a float?
        #TODO: extend the tests!









#----------------------------------------------------------------------------------------------------------------------------------------------
#       TODO: discuss which of the secondary functions is required (+which need to be tested)
# ----------------------------------------------------------------------------------------------------------------------------------------------

# ---------------------------------------------
#
#  Secondairy/Detailed test functions (GETTERS)
#
# ---------------------------------------------
class test_Core_Secondary_get(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds

    # ---------------------------------node: Product attribute: Name--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getProductName(self):
        ProductName = None
        if self.model != None:
            ProductName = self.KB_Interface.getProductName()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            ProductName = self.KB_Interface.getProductName()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(ProductName, "OldGearBox")



    # ---------------------------------node: Product attribute: STEPfile--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getProductSTEPfile(self):
        ProductSTEPfile = None
        if self.model != None:
            ProductSTEPfile = self.KB_Interface.getProductSTEPfile()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            ProductSTEPfile = self.KB_Interface.getProductSTEPfile()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(ProductSTEPfile, "C:/Users/alexander.decock/Local Documents/SVN/PACo/RuleTestsForUGM/data/FCStd/OldGearBox.FCStd")


    # ---------------------------------node: GroundPosition attribute: X--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getGroundPositionX(self):
        GroundPositionX = None
        if self.model != None:
            GroundPositionX = self.KB_Interface.getGroundPositionX()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            GroundPositionX = self.KB_Interface.getGroundPositionX()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GroundPositionX, 0.0)

    # ---------------------------------node: GroundPosition attribute: Y--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getGroundPositionY(self):
        GroundPositionY = None
        if self.model != None:
            GroundPositionY = self.KB_Interface.getGroundPositionY()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            GroundPositionY = self.KB_Interface.getGroundPositionY()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GroundPositionY, 0.0)

    # ---------------------------------node: GroundPosition attribute: Z--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getGroundPositionZ(self):
        GroundPositionZ = None
        if self.model != None:
            GroundPositionZ = self.KB_Interface.getGroundPositionZ()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            GroundPositionZ = self.KB_Interface.getGroundPositionZ()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GroundPositionZ, 0.0)

     # ---------------------------------node: GravityDirection attribute: X--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getGravityDirectionX(self):
        GravityDirectionX = None
        if self.model != None:
            GravityDirectionX = self.KB_Interface.getGravityDirectionX()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            GravityDirectionX = self.KB_Interface.getGravityDirectionX()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GravityDirectionX, 0.0)

    # ---------------------------------node: GravityDirection attribute: Y--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getGravityDirectionY(self):
        GravityDirectionY = None
        if self.model != None:
            GravityDirectionY = self.KB_Interface.getGravityDirectionY()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            GravityDirectionY = self.KB_Interface.getGravityDirectionY()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GravityDirectionY, -1.0)

     # ---------------------------------node: GravityDirection attribute: Z--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getGravityDirectionZ(self):
        GravityDirectionZ = None
        if self.model != None:
            GravityDirectionZ = self.KB_Interface.getGravityDirectionZ()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            GravityDirectionZ = self.KB_Interface.getGravityDirectionZ()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GravityDirectionZ, 0.0)



    # ---------------------------------node: ProductPart attribute: type--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getProductParttype(self):
        ProductParttype = None
        if self.model != None:
            ProductParttype = self.KB_Interface.getProductPartType('(3) Input Shaft')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            ProductParttype = self.KB_Interface.getProductPartType('(3) Input Shaft')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(ProductParttype, 'Unknown')

    @unittest.skip("To be discussed - Needed within the API?")
    def test_setProductParttype(self):
        ProductParttype = None
        if self.model != None:
            self.KB_Interface.setProductParttype('(3) Input Shaft',"newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setProductParttype('(3) Input Shaft',"newName")

            ProductParttype = self.KB_Interface.getProductPartType('(3) Input Shaft')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(ProductParttype, "newName")

    # ---------------------------------node: Operator attribute: name--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getOperatorname(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: reach--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getOperatorreach(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: height--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getOperatorheight(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: maxLiftingWeight--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getOperatormaxLiftingWeight(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)
    # ---------------------------------node: Operator attribute: costPerHour--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getOperators(self):
        operatorList = []
        if self.model != None:
            operatorList = self.KB_Interface.getOperators()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            operatorList = self.KB_Interface.getOperators()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(len(operatorList), 0)

    # ---------------------------------node: Analysis attribute: analysisFile--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAnalysis(self):
        AnalysisList = None
        if self.model != None:
            AnalysisList = self.KB_Interface.getAnalysis()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            AnalysisList = self.KB_Interface.getAnalysis()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(len(AnalysisList), 4)


    # ---------------------------------node: Analysis attribute: type--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAnalysistype(self):
        Analysistype = None
        if self.model != None:
            Analysistype = self.KB_Interface.getAnalysistype('Static Structural')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            Analysistype = self.KB_Interface.getAnalysistype('Static Structural')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(Analysistype, 'Static Structural')

    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAnalysisResponsePoints(self):
        responsePointList = None
        if self.model != None:
            responsePointList = self.KB_Interface.getAnalysisResponsePoints('Static Structural')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            responsePointList = self.KB_Interface.getAnalysisResponsePoints('Static Structural')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(len(responsePointList), 0) #TODO: not in example so not testable


    # ---------------------------------node: Analysis attribute: BoundaryCondition--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAnalysisBoundaryCondition(self):
        AnalysisBoundaryCondition = None
        if self.model != None:
            productPart,contactFeatures,blockDOF = self.KB_Interface.getAnalysisBoundaryCondition('Static Structural')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            productPart,contactFeatures,blockDOF = self.KB_Interface.getAnalysisBoundaryCondition('Static Structural')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(productPart, "(5) Output Shaft")
        self.assertEqual(contactFeatures[0], "ContactFeatures.FCstd")
        self.assertEqual(contactFeatures[1], "ContactFeatures.FCstd")
        self.assertEqual(contactFeatures[2], "ContactFeatures.FCstd")
        self.assertEqual(blockDOF[0],False)
        self.assertEqual(blockDOF[1], False)
        self.assertEqual(blockDOF[2], True)
        self.assertEqual(blockDOF[3], False)
        self.assertEqual(blockDOF[4], False)
        self.assertEqual(blockDOF[5], True)

    # ---------------------------------node: AnalysisParameter attribute: type--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAnalysisParameters(self):
        AnalysisParameterList = None
        if self.model != None:
            AnalysisParameterList = self.KB_Interface.getAnalysisParameters('Static Structural')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            AnalysisParameterList = self.KB_Interface.getAnalysisParameters('Static Structural')        #TODO: get analysis via type is not sufficient -> name needed
        # -----------------------CHECKS----------------------------------
        self.assertEqual(AnalysisParameterList[0][0], "Input")
        self.assertEqual(AnalysisParameterList[0][1], "[100mm]")
        self.assertEqual(AnalysisParameterList[1][0], "Output")
        self.assertEqual(AnalysisParameterList[1][1], "[1000Nm^-1]")



    # ---------------------------------node: AnalysisParameter attribute: name--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAnalysisParametername(self):        #TODO: analysisParameter is not conform the MM!
        obsolete = True        #TODO: discuss if obsolete
        self.assertEqual(obsolete, True)



    # ---------------------------------node: AnalysisParameter attribute: value--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAnalysisParametervalue(self):       #TODO: analysisParameter is not conform the MM!
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)


    # ---------------------------------node: Parameter attribute: parameterEffect--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getParameterparameterEffect(self):         #TODO: analysisParameter is not conform the MM!
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Load attribute: all--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getLoad(self):
        LoadList = []
        if self.model != None:
            LoadList = self.KB_Interface.getLoad('Static Structural')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            LoadList = self.KB_Interface.getLoad('Static Structural')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(LoadList[0][0], 'Static load')
        self.assertEqual(LoadList[0][1], 1000.0)
        self.assertEqual(LoadList[0][2], ['ContactFeatures.FCstd', 'ContactFeatures.FCstd', 'ContactFeatures.FCstd'])
        self.assertEqual(LoadList[0][3], '(3) Input Shaft')
        self.assertEqual(LoadList[0][4], [0.0, 0.0, 0.0])

    # ---------------------------------node: Tool attribute: name--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getToolname(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)


    # ---------------------------------node: Tool attribute: mass--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getToolmass(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Tool attribute: cost--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getTools(self):
        toolList = None
        if self.model != None:
            toolList = self.KB_Interface.getTools()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            toolList = self.KB_Interface.getTools()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(len(toolList), 0)


    # ---------------------------------node: OperationMetric attribute: name--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getOperationMetricname(self):
        OperationMetricname = None
        if self.model != None:
            OperationMetricname = self.KB_Interface.getOperationMetricname()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            OperationMetricname = self.KB_Interface.getOperationMetricname()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(OperationMetricname, "Total Score")


    # ---------------------------------node: OperationMetric attribute: value--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getOperationMetricvalue(self):
        OperationMetricvalue = None
        if self.model != None:
            OperationMetricvalue = self.KB_Interface.getOperationMetricvalue()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            OperationMetricvalue = self.KB_Interface.getOperationMetricvalue()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(OperationMetricvalue, "-inf")


    # ---------------------------------node: AssemblyMetric attribute: value--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getAssemblyMetricvalue(self):          #TODO: Not in current example!
        AssemblyMetricvalue = None
        if self.model != None:
            AssemblyMetricvalue = self.KB_Interface.getAssemblyMetricvalue()
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            AssemblyMetricvalue = self.KB_Interface.getAssemblyMetricvalue()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(AssemblyMetricvalue, -1)   #TODO: No metrics in examples! -> discuss to make an example that contains everything


    #---------------------------------node: Material attribute: name--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getMaterialname(self):
        Materialname = None
        if self.model != None:
            Materialname = self.KB_Interface.getMaterialname('(5) Output Shaft')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            Materialname = self.KB_Interface.getMaterialname('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialname,"Structural Steel")


     #---------------------------------node: Material attribute: density--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getMaterialdensity(self):
        Materialdensity = None
        if self.model != None:
            Materialdensity = self.KB_Interface.getMaterialdensity('(5) Output Shaft')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            Materialdensity = self.KB_Interface.getMaterialdensity('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialdensity,7850.0)


     #---------------------------------node: Material attribute: cost--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getMaterialcost(self):
        Materialcost = None
        if self.model != None:
            Materialcost = self.KB_Interface.getMaterialcost('(5) Output Shaft')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            Materialcost = self.KB_Interface.getMaterialcost('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialcost,0.0)


     #---------------------------------node: Material attribute: damping--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getMaterialdamping(self):
        Materialdamping = None
        if self.model != None:
            Materialdamping = self.KB_Interface.getMaterialdamping('(5) Output Shaft')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            Materialdamping = self.KB_Interface.getMaterialdamping('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialdamping,0.0)

     #---------------------------------node: Material attribute: youngModulus--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getMaterialyoungModulus(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)


     #---------------------------------node: Material attribute: poissonRatio--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getMaterialpoissonRatio(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)


     #---------------------------------node: Material attribute: transparency--------------------------------------------------------------------
    @unittest.skip("To be discussed - Needed within the API?")
    def test_getMaterialtransparency(self):
        Materialtransparency = None
        if self.model != None:
            Materialtransparency = self.KB_Interface.getMaterialtransparency('(5) Output Shaft')
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            Materialtransparency = self.KB_Interface.getMaterialtransparency('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialtransparency,0.0)

# ---------------------------------------------
#
#  Secondairy/Detailed test functions (UPDATE)
#
# ---------------------------------------------
class test_Core_Secondary_update(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds

# ---------------------------------------------
#
#  Secondairy/Detailed test functions (SETTERS)
#       TODO:setter functions do not work yet -> test functions not tested!
# ---------------------------------------------
class test_Core_Secondary_set(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setProductName(self):
        ProductName = None
        if self.model != None:
            self.KB_Interface.setProductName("newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setProductName("newName")

            ProductName = self.KB_Interface.getProductName()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(ProductName, "newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setMaterialdamping(self):
        Materialdamping = None
        if self.model != None:
             self.KB_Interface.setMaterialdamping('(5) Output Shaft',10.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setMaterialdamping('(5) Output Shaft',10.0)

            Materialdamping = self.KB_Interface.getMaterialdamping('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialdamping,10.0)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setMaterialyoungModulus(self):
        MaterialyoungModulus = None
        if self.model != None:
             self.KB_Interface.setMaterialyoungModulus('(5) Output Shaft',10.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setMaterialyoungModulus('(5) Output Shaft',10.0)

            MaterialyoungModulus = self.KB_Interface.getMaterialyoungModulus('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(MaterialyoungModulus,10.0)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setMaterialpoissonRatio(self):
        MaterialpoissonRatio = None
        if self.model != None:
             self.KB_Interface.setMaterialpoissonRatio('(5) Output Shaft',10.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setMaterialpoissonRatio('(5) Output Shaft',10.0)

            MaterialpoissonRatio = self.KB_Interface.getMaterialpoissonRatio('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(MaterialpoissonRatio,10.0)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setMaterialtransparency(self):
        Materialtransparency = None
        if self.model != None:
             self.KB_Interface.setMaterialtransparency('(5) Output Shaft',10.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setMaterialtransparency('(5) Output Shaft',10.0)

            Materialtransparency = self.KB_Interface.getMaterialtransparency('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialtransparency,10.0)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setMaterialcost(self):
        Materialcost = None
        if self.model != None:
             self.KB_Interface.setMaterialcost('(5) Output Shaft',10.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setMaterialcost('(5) Output Shaft',10.0)

            Materialcost = self.KB_Interface.getMaterialcost('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialcost,10.0)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setMaterialdensity(self):
        Materialdensity = None
        if self.model != None:
             self.KB_Interface.setMaterialdensity('(5) Output Shaft',10.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setMaterialdensity('(5) Output Shaft',10.0)

            Materialdensity = self.KB_Interface.getMaterialdensity('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialdensity,10.0)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setMaterialname(self):
        Materialname = None
        if self.model != None:
             self.KB_Interface.setMaterialname('(5) Output Shaft',"newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setMaterialname('(5) Output Shaft',"newName")

            Materialname = self.KB_Interface.getMaterialname('(5) Output Shaft')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(Materialname,"newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setOperationMetricvalue(self):
        OperationMetricvalue = None
        if self.model != None:
            self.KB_Interface.setOperationMetricvalue("newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setOperationMetricvalue("newName")

            OperationMetricvalue = self.KB_Interface.getOperationMetricvalue()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(OperationMetricvalue, "newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAssemblyMetricvalue(self):          #TODO: Not really needed as it needs to be linked to the assembly sequence
        AssemblyMetricvalue = None
        if self.model != None:
            self.KB_Interface.setAssemblyMetricvalue("newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setAssemblyMetricvalue("newName")

            AssemblyMetricvalue = self.KB_Interface.getAssemblyMetricvalue()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(AssemblyMetricvalue, "newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setOperationMetricname(self):
        OperationMetricname = None
        if self.model != None:
            self.KB_Interface.setOperationMetricname("newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setOperationMetricname("newName")

            OperationMetricname = self.KB_Interface.getOperationMetricname()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(OperationMetricname, "newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setTools(self):
        ToolList = [['Wrench',25.0,125.0,'orientationData',['operator-1',100.0,178.0,55.0,65.0],'geometrydata']]
        if self.model != None:
            self.KB_Interface.setTools(ToolList)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            ToolList = [['Wrench',25.0,125.0,'orientationData',['operator-1',100.0,178.0,55.0,65.0],'geometrydata']]
            self.KB_Interface.setTools(ToolList)

            list = self.KB_Interface.getTools()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(list[0][0], "Wrench")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setToolmass(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setToolname(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setLoad(self):         #TODO: this needs discussion if needed! ==> lots of dependencies!
        Loadtype = None
        if self.model != None:
            self.KB_Interface.setLoadtype("newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setLoadtype("newName")

            Loadtype = self.KB_Interface.getLoadtype()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(Loadtype, "newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setParameterparameterEffect(self):         #TODO: analysisParameter is not conform the MM!
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAnalysisParametervalue(self):       #TODO: analysisParameter is not conform the MM!
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAnalysisParametername(self):        #TODO: analysisParameter is not conform the MM!
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAnalysisParametertype(self):            #TODO: analysisParameter is not conform the MM!
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: name--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setOperatorname(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: reach--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setOperatorreach(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: height--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setOperatorheight(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: maxLiftingWeight--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setOperatormaxLiftingWeight(self):
        obsolete = True  # TODO: discuss if obsolete
        self.assertEqual(obsolete, True)

    # ---------------------------------node: Operator attribute: costPerHour--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setOperators(self):
        operatorList = [['operator-1', 100.0, 178.0, 55.0, 65.0]]
        if self.model != None:
            self.KB_Interface.setOperators(operatorList)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            operatorList = [['operator-1', 100.0, 178.0, 55.0, 65.0]]
            self.KB_Interface.setOperators(operatorList)

            list = self.KB_Interface.getOperators()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(list[0][0], "operator-1")

    # ---------------------------------node: Analysis attribute: analysisFile--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAnalysFile(self):
        AnalysisanalysisFile = None
        if self.model != None:
            self.KB_Interface.setAnalysisanalysisFile('Static Structural', "newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setAnalysisanalysisFile('Static Structural', "newName")

            AnalysisanalysisFile = self.KB_Interface.getAnalysisFile('Static Structural')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(AnalysisanalysisFile, "newName")

    # ---------------------------------node: Analysis attribute: type--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAnalysistype(self):
        Analysistype = None
        if self.model != None:
            self.KB_Interface.setAnalysistype('Static Structural', "newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setAnalysistype('Static Structural', "newName")

            Analysistype = self.KB_Interface.getAnalysistype("newName")
        # -----------------------CHECKS----------------------------------
        self.assertEqual(Analysistype, "newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAnalysisResponsePoints(
            self):  # TODO: discuss to have an ID instead of type ==> multiple same types!!
        list = [['RP1', 0.0, 0.0, 0.0]]
        Analysistype = None
        if self.model != None:
            self.KB_Interface.setAnalysisResponsePoints('Static Structural', list)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            list = [['RP1', 0.0, 0.0, 0.0]]
            self.KB_Interface.setAnalysisResponsePoints('Static Structural', list)

            analysisResponsPoints = self.KB_Interface.getAnalysisResponsePoints('Static Structural')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(analysisResponsPoints[0][0], "RP1")

    # ---------------------------------node: Analysis attribute: BoundaryCondition--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setAnalysisBoundaryCondition(
            self):  # TODO: this needs discussion if needed! ==> lot of dependencies so lot of init components needed!!
        AnalysisBoundaryCondition = None
        if self.model != None:
            self.KB_Interface.setAnalysisBoundaryCondition("newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setAnalysisBoundaryCondition("newName")

            AnalysisBoundaryCondition = self.KB_Interface.getAnalysisBoundaryCondition()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(AnalysisBoundaryCondition, "newName")

    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setProductSTEPfile(self):
        ProductSTEPfile = None
        if self.model != None:
            self.KB_Interface.setProductSTEPfile("newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setProductSTEPfile("newName")

            ProductSTEPfile = self.KB_Interface.getProductSTEPfile()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(ProductSTEPfile, "newName")

    # ---------------------------------node: GroundPosition attribute: X--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setGroundPositionX(self):
        GroundPositionX = None
        if self.model != None:
            self.KB_Interface.setGroundPositionX(1.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setGroundPositionX(1.0)

            GroundPositionX = self.KB_Interface.getGroundPositionX()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GroundPositionX, 1.0)

    # ---------------------------------node: GroundPosition attribute: Y--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setGroundPositionY(self):
        GroundPositionY = None
        if self.model != None:
            self.KB_Interface.setGroundPositionY(1.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setGroundPositionY(1.0)

            GroundPositionY = self.KB_Interface.getGroundPositionY()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GroundPositionY, 1.0)

    # ---------------------------------node: GroundPosition attribute: Z--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setGroundPositionZ(self):
        GroundPositionZ = None
        if self.model != None:
            self.KB_Interface.setGroundPositionZ(1.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setGroundPositionZ(1.0)

            GroundPositionZ = self.KB_Interface.getGroundPositionZ()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GroundPositionZ, 1.0)

    # ---------------------------------node: GravityDirection attribute: X--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setGravityDirectionX(self):
        GravityDirectionX = None
        if self.model != None:
            self.KB_Interface.setGravityDirectionX(1.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setGravityDirectionX(1.0)

            GravityDirectionX = self.KB_Interface.getGravityDirectionX()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GravityDirectionX, 1.0)

    # ---------------------------------node: GravityDirection attribute: Y--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setGravityDirectionY(self):
        GravityDirectionY = None
        if self.model != None:
            self.KB_Interface.setGravityDirectionY(1.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setGravityDirectionY(1.0)

            GravityDirectionY = self.KB_Interface.getGravityDirectionY()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GravityDirectionY, 1.0)

    # ---------------------------------node: GravityDirection attribute: Z--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setGravityDirectionZ(self):
        GravityDirectionZ = None
        if self.model != None:
            self.KB_Interface.setGravityDirectionZ(1.0)
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setGravityDirectionZ(1.0)

            GravityDirectionZ = self.KB_Interface.getGravityDirectionZ()
        # -----------------------CHECKS----------------------------------
        self.assertEqual(GravityDirectionZ, 1.0)

    # ---------------------------------node: ProductPart attribute: name--------------------------------------------------------------------
    @unittest.skip("Function-under-test not yet implemented or incomplete")
    def test_setProductPartname(self):
        ProductPartname = None
        if self.model != None:
            self.KB_Interface.setProductPartname('(3) Input Shaft', "newName")
        else:
            path_ecore = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/MM/PACoMM.ecore'
            path_KB = 'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/OldGearBox.xmi'
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setProductPartname('(3) Input Shaft', "newName")

            ProductParts = self.KB_Interface.getProductParts()
            found = 0
            for part in ProductParts:
                if part[0] == "newName":
                    found = 1
        # -----------------------CHECKS----------------------------------
        self.assertEqual(found, 1)


