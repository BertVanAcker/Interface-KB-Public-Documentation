import unittest
import time
from Interface_KB import KB_Interface,InterfaceObjects
from Interface_KB.InterfaceObjects import ASG ,StopCondition

class test_ASG(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds

    def test_getASG(self):
        if self.model != None:
            ASG = self.KB_Interface.getASG('ASG-1')
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')    #TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_getASG.pacopackage') #'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/KB_examples/test_getASG.pacopackage'       #TODO: adapt to one version!!
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getASG('ASG-1')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "ASG-1-config")
        self.assertEqual(InterfaceObject_received.Description, "AssemblySequenceDraft1")
        # self.assertEqual(ASG[2], "Full=0")#TODO: check how we can validate this
        # generator
        self.assertEqual(InterfaceObject_received.Generator[0], "Gen-1")
        self.assertEqual(InterfaceObject_received.Generator[1], "SinglePartGenerator")
        # selector
        self.assertEqual(InterfaceObject_received.Selector[0], "Sel-1")
        self.assertEqual(InterfaceObject_received.Selector[1], "RuleSelector")
        # Evaluator
        self.assertEqual(InterfaceObject_received.Evaluator[0], "Eval-1")
        self.assertEqual(InterfaceObject_received.Evaluator[1], "RuleEvaluator")
        # terminator
        self.assertEqual(len(InterfaceObject_received.StopConditionList), 2)
        # contained stopcriteria
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Name, 'Stop-1')
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Description, 'Maximum depth of search')
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Value, 100.0)
        # self.assertEqual(InterfaceObject_received.StopConditionList[0].StopCriteria, maxDepth=0) #TODO: check how we can validate this
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Name, 'Stop-2')
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Description, 'Maximum time of search')
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Value, 3600.0)

    def test_updateASG(self):

        # load the json file to perform update
        jsonPath = self.KB_Interface.resolvePath('input/JSON-docs/updateASGModel.json')
        interfaceObject = InterfaceObjects.ASG(jsonPath)

        if self.model != None:
            ASG = self.KB_Interface.getASG('ASG-1')
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_updateASG.pacopackage') #'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/KB_examples/test_getASG.pacopackage'       #TODO: adapt to one version!!
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)

            #updating the ASG model
            error = self.KB_Interface.updateASG(AssemblySystemName='ASG-1',interfaceObject=interfaceObject)

            # verify update by re-importing
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getASG('ASG-1')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "ASG-1-config")
        self.assertEqual(InterfaceObject_received.Description, "AssemblySequenceDraft1 NEW")
        # self.assertEqual(ASG[2], "Full=0")#TODO: check how we can validate this
        # generator
        self.assertEqual(InterfaceObject_received.Generator[0], "Gen-1")
        self.assertEqual(InterfaceObject_received.Generator[1], "SinglePartGenerator")
        # selector
        self.assertEqual(InterfaceObject_received.Selector[0], "Sel-1")
        self.assertEqual(InterfaceObject_received.Selector[1], "RuleSelector")
        # Evaluator
        self.assertEqual(InterfaceObject_received.Evaluator[0], "Eval-1")
        self.assertEqual(InterfaceObject_received.Evaluator[1], "RuleEvaluator")
        # terminator
        self.assertEqual(len(InterfaceObject_received.StopConditionList), 2)
        # contained stopcriteria
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Name, 'Stop-1')
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Description, 'Maximum depth of search NEW')
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Value, 100.0)
        # self.assertEqual(InterfaceObject_received.StopConditionList[0].StopCriteria, maxDepth=0) #TODO: check how we can validate this
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Name, 'Stop-2')
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Description, 'Maximum time of search NEW')
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Value, 3600.0)

    def test_setASG(self):
        ASG_temp = []
        #------------------------specify interface object START -----------------------------
        stopConditions = []
        s1 = StopCondition(None,"Stop-1","Maximum depth of search",1000.0,"maxDepth=0")
        s2 = StopCondition(None, "Stop-2","Maximum time of search",360.0,"maxDepth=1")
        stopConditions.append(s1)
        stopConditions.append(s2)
        ASG_interface = ASG(None,Name='ASG-1-config', Description='AssemblySequenceDraft1',ProcessingType="Full=0",Generator=['GenNew-1','SinglePartGenerator'],Selector=['SelNew-1','RuleSelector'],Evaluator=['EvalNew-1','RuleEvaluator'],StopConditions=stopConditions)
        # ------------------------specify interface object END  -----------------------------

        if self.model != None:
            self.KB_Interface.setASG('ASG-1',ASG_interface)
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_setASG.pacopackage')  # TODO: adapt to one version!!
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            self.KB_Interface.setASG('ASG-1',ASG_interface)
            InterfaceObject_received = self.KB_Interface.getASG('ASG-1')
        # -----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "ASG-1-config")
        self.assertEqual(InterfaceObject_received.Description, "AssemblySequenceDraft1")
        # self.assertEqual(ASG[2], "Full=0")#TODO: check how we can validate this
        # generator
        self.assertEqual(InterfaceObject_received.Generator[0], "GenNew-1")
        self.assertEqual(InterfaceObject_received.Generator[1], "SinglePartGenerator")
        # selector
        self.assertEqual(InterfaceObject_received.Selector[0], "SelNew-1")
        self.assertEqual(InterfaceObject_received.Selector[1], "RuleSelector")
        # Evaluator
        self.assertEqual(InterfaceObject_received.Evaluator[0], "EvalNew-1")
        self.assertEqual(InterfaceObject_received.Evaluator[1], "RuleEvaluator")
        # terminator
        self.assertEqual(len(InterfaceObject_received.StopConditionList), 2)
        # contained stopcriteria
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Name, 'Stop-1')
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Description, 'Maximum depth of search')
        self.assertEqual(InterfaceObject_received.StopConditionList[0].Value, 1000.0)
        # self.assertEqual(InterfaceObject_received.StopConditionList[0].StopCriteria, maxDepth=0) #TODO: check how we can validate this
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Name, 'Stop-2')
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Description, 'Maximum time of search')
        self.assertEqual(InterfaceObject_received.StopConditionList[1].Value, 360.0)


