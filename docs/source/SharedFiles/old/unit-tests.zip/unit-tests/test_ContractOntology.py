import unittest
import time
from Interface_KB import KB_Interface,InterfaceObjects
from Interface_KB.InterfaceObjects import ASG,StopCondition,PerformanceModel

class test_ContractOntology(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds

    def test_getContract(self):
        if self.model != None:
            InterfaceObject_received = self.KB_Interface.getContract('C-1')
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version7/PACoMM.ecore')    #TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/ContractOntology_example1.pacopackage')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getContract('C-1')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "C-1")
        self.assertEqual(InterfaceObject_received.Description, "Co-desgin contract C-1")
        #assumptions
        self.assertEqual(len(InterfaceObject_received.Assumptions), 3)
        #TODO: extend the tests
        #guarantees
        self.assertEqual(len(InterfaceObject_received.Guarantees), 2)
        # TODO: extend the tests


    def test_getOntology(self):
        if self.model != None:
            InterfaceObject_received = self.KB_Interface.getContract('C-1')
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version7/PACoMM.ecore')    #TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/ContractOntology_example1.pacopackage')
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getOntology()
        #-----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "Not in MM")
        self.assertEqual(InterfaceObject_received.Description, "Not in MM")
        #assumptions
        #self.assertEqual(len(InterfaceObject_received.Assumptions), 3)
        #TODO: extend the tests
        #guarantees
        #self.assertEqual(len(InterfaceObject_received.Guarantees), 2)
        # TODO: extend the tests






