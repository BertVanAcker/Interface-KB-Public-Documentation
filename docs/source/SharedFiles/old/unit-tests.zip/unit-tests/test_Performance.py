import unittest
import time
from Interface_KB import KB_Interface,InterfaceObjects
from Interface_KB.InterfaceObjects import ASG,StopCondition,PerformanceModel

class test_Performance(unittest.TestCase):
    def setUp(self):
        self.KB_Interface = KB_Interface.KB_Interface(True)
        self.model = None
        pass

    def tearDown(self):
        time.sleep(1)  # sleep time in seconds

    def test_getPerformance(self):
        if self.model != None:
            InterfaceObject_received = self.KB_Interface.getPerformance('OPTIMIZATION-v1')
        else:
            path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')    #TODO: adapt to one version!!    #TODO: adapt to one version!!
            path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_getPerformance.pacopackage') #'C:/Users/B.MKR/Documents/06_PhD/03_Projects/03_PaCo/paco-workspace/knowledgebase-interface/unit-tests/input/KB_examples/test_getASG.pacopackage'       #TODO: adapt to one version!!
            self.KB_Interface.KB_path = path_KB  # To update current KB
            self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
            InterfaceObject_received = self.KB_Interface.getPerformance('OPTIMIZATION-v1')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "OPTIMIZATION-v1")
        self.assertEqual(InterfaceObject_received.Description, "Optimization problem v1")
        #optimization method
        self.assertEqual(InterfaceObject_received.OptimizationMethod[0], "HEURISTIC-M01")
        self.assertEqual(InterfaceObject_received.OptimizationMethod[1], "Heuristic method")
        self.assertEqual(InterfaceObject_received.OptimizationMethod[2], "Heuristic")
        #stop conditions
        stopList = InterfaceObject_received.StopConditionList
        self.assertEqual(len(stopList), 2)
        #stop1
        self.assertEqual(stopList[0].Name, "STOP-1")
        self.assertEqual(stopList[0].Description, "Stop criterion 1")
        self.assertEqual(stopList[0].Value,3600.0)
        self.assertEqual(stopList[0].StopCriteria, "maxTime")
        # stop2
        self.assertEqual(stopList[1].Name, "STOP-2")
        self.assertEqual(stopList[1].Description, "Stop criterion 2")
        self.assertEqual(stopList[1].Value, 15001.0)
        self.assertEqual(stopList[1].StopCriteria, "maxDepth")
        # Objectives
        ObjectiveList = InterfaceObject_received.ObjectiveList
        self.assertEqual(len(ObjectiveList), 1)
        # Objective1
        self.assertEqual(ObjectiveList[0].Name, "MIN-MASS")
        self.assertEqual(ObjectiveList[0].Description, "Minimize the total mass")
        self.assertEqual(ObjectiveList[0].ObjectiveOption[0], "Mass_var")
        self.assertEqual(ObjectiveList[0].ObjectiveOption[1], "Total mass variable")
        self.assertEqual(ObjectiveList[0].ObjectiveOption[2], 81.0)
        # Contraints
        ContraintList = InterfaceObject_received.ConstraintList
        self.assertEqual(len(ContraintList), 1)
        # Constraint 1
        self.assertEqual(ContraintList[0].Name, "CONSTRAINT1")
        self.assertEqual(ContraintList[0].Description, "Constraint1")
        #expression left
        self.assertEqual(ContraintList[0].Expression[0][0], "LEFT")
        self.assertEqual(ContraintList[0].Expression[0][1], "Mass_var")
        self.assertEqual(ContraintList[0].Expression[0][2], "Total mass variable")
        self.assertEqual(ContraintList[0].Expression[0][3], 81.0)
        # expression right
        self.assertEqual(ContraintList[0].Expression[1][0], "RIGHT")
        self.assertEqual(ContraintList[0].Expression[1][1], 85.0)
        # operator
        self.assertEqual(ContraintList[0].Expression[2], "<")
        # Decision Variable list
        dvList = InterfaceObject_received.parameterList
        self.assertEqual(len(dvList), 1)
        #decision Variable 1
        self.assertEqual(dvList[0].Name, "Mass_var")
        self.assertEqual(dvList[0].Description, "Total mass variable")
        self.assertEqual(dvList[0].InitialValue, 10.0)
        self.assertEqual(dvList[0].MinValue, 10.0)
        self.assertEqual(dvList[0].MaxValue, 100.0)
        self.assertEqual(dvList[0].Optimum, 81.0)
        self.assertEqual(dvList[0].Resolution, 0.1)
        #referenced Parameter
        self.assertEqual(dvList[0].parameterList[0].Name, "Mass")
        self.assertEqual(dvList[0].parameterList[0].Description, "Total mass parameter")
        self.assertEqual(dvList[0].parameterList[0].Key, "MASS")
        self.assertEqual(dvList[0].parameterList[0].GUID, None)

    def test_updatePerformance(self):

        #load the json file to perform update
        jsonPath = self.KB_Interface.resolvePath('input/JSON-docs/updatePerformanceModel.json')
        interfaceObject = PerformanceModel(jsonPath)

        path_ecore = self.KB_Interface.resolvePath('input/metamodel/Version-6-1/PACoMM.ecore')  # TODO: adapt to one version!!    #TODO: adapt to one version!!
        path_KB = self.KB_Interface.resolvePath('input/KB_examples/test_updatePerformance.pacopackage')    #TODO: adapt to one version!!
        self.KB_Interface.KB_path = path_KB  # To update current KB
        self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
        #perform update
        error = self.KB_Interface.updatePerformance(interfaceObject)
        #verify update by re-importing
        self.model = self.KB_Interface.importInstanceModel(path_ecore, path_KB)
        InterfaceObject_received = self.KB_Interface.getPerformance('OPTIMIZATION-v1')
        #-----------------------CHECKS----------------------------------
        self.assertEqual(InterfaceObject_received.Name, "OPTIMIZATION-v1")
        self.assertEqual(InterfaceObject_received.Description, "This is the new description")
        #optimization method
        self.assertEqual(InterfaceObject_received.OptimizationMethod[0], "HEURISTIC-M01")
        self.assertEqual(InterfaceObject_received.OptimizationMethod[1], "Heuristic method NEW")
        self.assertEqual(InterfaceObject_received.OptimizationMethod[2], "Heuristic")
        #stop conditions
        stopList = InterfaceObject_received.StopConditionList
        self.assertEqual(len(stopList), 2)
        #stop1
        self.assertEqual(stopList[0].Name, "STOP-1")
        self.assertEqual(stopList[0].Description, "Stop criterion 1 NEW")
        self.assertEqual(stopList[0].Value,100.0)
        self.assertEqual(stopList[0].StopCriteria, "maxTime")
        # stop2
        self.assertEqual(stopList[1].Name, "STOP-2")
        self.assertEqual(stopList[1].Description, "Stop criterion 2 NEW")
        self.assertEqual(stopList[1].Value, 22250.0)
        self.assertEqual(stopList[1].StopCriteria, "maxDepth")
        # Objectives
        ObjectiveList = InterfaceObject_received.ObjectiveList
        self.assertEqual(len(ObjectiveList), 1)
        # Objective1
        #self.assertEqual(ObjectiveList[0].Name, "MIN-MASS")
        #self.assertEqual(ObjectiveList[0].Description, "Minimize the total mass NEW")
        #self.assertEqual(ObjectiveList[0].ObjectiveOption[0], "Mass_var")
        #self.assertEqual(ObjectiveList[0].ObjectiveOption[1], "Total mass variable")
        #self.assertEqual(ObjectiveList[0].ObjectiveOption[2], 55.0)
        # Contraints
        ContraintList = InterfaceObject_received.ConstraintList
        self.assertEqual(len(ContraintList), 1)
        # Constraint 1
        #self.assertEqual(ContraintList[0].Name, "CONSTRAINT1")
        #self.assertEqual(ContraintList[0].Description, "Constraint1 NEW")
        #expression left
        #self.assertEqual(ContraintList[0].Expression[0][0], "LEFT")
        #self.assertEqual(ContraintList[0].Expression[0][1], "Mass_var")
        #self.assertEqual(ContraintList[0].Expression[0][2], "Total mass variable")
        #self.assertEqual(ContraintList[0].Expression[0][3], 81.0)
        # expression right
        #self.assertEqual(ContraintList[0].Expression[1][0], "RIGHT")
        #self.assertEqual(ContraintList[0].Expression[1][1], 85.0)
        # operator
        #self.assertEqual(ContraintList[0].Expression[2], "<")
        # Decision Variable list
        dvList = InterfaceObject_received.parameterList
        self.assertEqual(len(dvList), 1)
        #decision Variable 1
        self.assertEqual(dvList[0].Name, "Mass_var")
        self.assertEqual(dvList[0].Description, "Total mass variable")
        self.assertEqual(dvList[0].InitialValue, 10.0)
        self.assertEqual(dvList[0].MinValue, 10.0)
        self.assertEqual(dvList[0].MaxValue, 100.0)
        self.assertEqual(dvList[0].Optimum, 55.0)
        self.assertEqual(dvList[0].Resolution, 0.1)
        #referenced Parameter
        self.assertEqual(dvList[0].parameterList[0].Name, "Mass")
        self.assertEqual(dvList[0].parameterList[0].Description, "Total mass parameter")
        self.assertEqual(dvList[0].parameterList[0].Key, "MASS")
        self.assertEqual(dvList[0].parameterList[0].GUID, None)



